sap.ui.define([
	"ea/easystem/test/unit/controller/EA-System.controller"
], function () {
	"use strict";
});
