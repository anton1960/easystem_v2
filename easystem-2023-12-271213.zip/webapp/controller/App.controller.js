sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("ea.easystem.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  