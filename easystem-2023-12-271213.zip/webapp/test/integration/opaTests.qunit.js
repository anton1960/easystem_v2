/* global QUnit */

sap.ui.require(["ea/easystem/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
